# Anonymous Code Supplement

This archive contains the code for finite-support convolutional aggregate likelihoods for aggregate-supervised multiple-instance learning.

## Contents

- `src/countmil/`: library code for aggregate likelihoods, posterior computations, datasets, models, metrics, and training utilities.
- `scripts/`: experiment and benchmark entry points.
- `tests/`: numerical and training smoke tests.
- `configs/`: small non-identifying example configs for the main experiment families.
- `pyproject.toml`: minimal package metadata.

## Setup

Create an environment with Python 3.9 or newer, then install the package in editable mode:

```bash
pip install -e .
```

The package depends on PyTorch and NumPy. Dataset roots are configurable and default to `data/`. The code does not download datasets automatically unless a download script is run explicitly.

## Basic Checks

Run the core numerical tests with:

```bash
pytest tests/test_aggregators.py tests/test_posteriors.py
```

Run all tests with:

```bash
pytest
```

## Notes on Anonymization

This code supplement excludes paper sources, result directories, remote-machine manifests, reference PDFs, prior-work folders, and local experiment artifacts. Paths and configs included here are intended to be non-identifying.
