"""Training helpers."""

